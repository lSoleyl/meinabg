<?php 
require $RESS_ROOT_DIR . "/include/db.cfg";

function connect($host, $username, $password, $database)
{
	$con= mysql_connect($host,$username,$password) or die(mysql_error());
    mysql_select_db($database,$con) or die(mysql_error());  
}
connect($host, $username, $password, $database);

function render($page)
{
	$_SESSION['ACTION'] = $page;
	throw(new Exception("render"));
}
function redirect_to($action)
{
	$_SESSION['ACTION'] = $action;
	throw (new Exception("redirect_to"));
}
function action($action)
{
	return $RESS_ROOT_DIR . "/action/" . $action . ".ac";
}
function ReadFromFile($filename)
{
	$f = fopen($filename,"r");
	$content = @fread($f,filesize($filename));
	@fclose($f);
	return $content;
}

function post($varname, $alternate="") { //Wenn Post-Variable gesetzt, wird diese zurückgeliefert, ansonsten die alternative
	return !empty($_POST[$varname]) ? $_POST[$varname] : $alternate;
}

function get($varname, $alternate="") { //Wenn Get-Variable gesetzt, wird diese zurückgeliefert, ansonsten die alternative
	return !empty($_GET[$varname]) ? $_GET[$varname] : $alternate;
}

//Formular_Helper für die Actions
function input($name, $value="", $type="text") {
	return "<input type=\"$type\" name=\"$name\" value=\"$value\">"; 
}

function form($action) { //Post-Form - action = actionname
	return "<form method=post action=\"index.php?ACTION=$action\">"; 
}

function link_to($action) {
	return "<a href=\"index.php?ACTION=$action\">";
}

function error($message) {
	return "<div class=\"error\">$message</div>";
}

function set_hint($hint) {
	$_SESSION["__hint"] = $hint;
}

function hint() {
	$h = (empty($_SESSION["__hint"]) ? "" : $_SESSION["__hint"]);
	$_SESSION["__hint"] = "";
	return $h;
}

function check_login($level = 0) {
	if (empty($_SESSION["uid"]))
		redirect_to("login");
	if ($level > 0) {
		$result = mysql_query("SELECT ACCTYPE FROM `spieler` WHERE ID = " . uid());
		if (mysql_result($result, 0,0) < $level)
			penalty();
	}
		
}

function uid() {
    if (empty($_SESSION["uid"]))
	  $_SESSION["uid"] = "";
	return $_SESSION["uid"];
}


function accType() {
	if (empty($_SESSION["accType"])) {
		if (uid() != "") {
			$query = "SELECT ACCTYPE FROM `spieler` WHERE ID = " . uid();
			$result = mysql_query($query);
			$_SESSION["accType"] = mysql_result($result, 0,0);
		} else {
			return 0;
		}
	}
	return $_SESSION["accType"];
}

function penalty($amount=1000, $msg="") {
	redirect_to("overview");
	/*if (uid() != "")
	$query = "UPDATE `spieler` SET BALANCE=BALANCE-$amount WHERE ID=". uid();
	mysql_query($query);
	render("penalty");*/
}

function upTime() {
 if (empty($_SESSION["uptime"]))
   $_SESSION["uptime"] = 0;
  return $_SESSION["uptime"];
}

function setUpTime($time) {
 $_SESSION["uptime"] = $time;
}


require $RESS_ROOT_DIR . "/include/boerse_adapter.php";

function h($current = 0, $disable = false) {
$disabled = (uid() == "") || $disable;
$foa = "<font color=\"#CC0000\">";
$foe = "</font>";
$header  = "<div style=\"width:779px; height:168px;\">";
$header .= "<div id=\"rc1\"></div>";
$header .= "<div class=\"links_bg\">";
$c = 1;
$fa = ($current == $c) ? $foa : "";
$fe = ($current == $c) ? $foe : "";
$header .= "<div class=\"toplinks\"><a href=\"index.php?ACTION=overview\">".$fa."&Uuml;bersicht".$fe."</a></div>";
$header .= "<div class=\"sap\"></div>";
++$c;
$fa = ($current == $c) ? $foa : "";
$fe = ($current == $c) ? $foe : "";
$header .= "<div class=\"toplinks\"><a href=\"" . (!$disabled ? "index.php?ACTION=myshares" : "#") . "\">".$fa."Meine Aktien".$fe."</a></div>";
$header .= "<div class=\"sap\"></div>";
++$c;
$fa = ($current == $c) ? $foa : "";
$fe = ($current == $c) ? $foe : "";
$header .= "<div class=\"toplinks\"><a href=\"" . (!$disabled ? "index.php?ACTION=allshares" : "#") . "\">".$fa."Aktienkurse".$fe."</a></div>";
$header .= "</div>";
$header .= "<div id=\"logo\">";
$header .= "<div class=\"name\">";
$header .= "  <p>B&ouml;rsenspiel </p>";
$header .= "</div>";
$header .= "</div>";
$header .= "<div class=\"links_bg\">";
++$c;
$fa = ($current == $c) ? $foa : "";
$fe = ($current == $c) ? $foe : "";

$msg = "";
if (!$disabled) {
$query = "SELECT COUNT(*) FROM `nachricht` WHERE AN = " . uid() . " AND GELESEN = 0";
$result = mysql_query($query);
$msgs = mysql_result($result, 0,0);
$msg = ($msgs > 0) ? "<br>($msgs)" : "";
}
$header .= "<div class=\"toplinks\"><a href=\"" . (!$disabled ? "index.php?ACTION=messages" : "#") . "\">".$fa."Nachrichten".$fe."</a>$msg</div>";
$header .= "<div class=\"sap\"></div>";
++$c;
$fa = ($current == $c) ? $foa : "";
$fe = ($current == $c) ? $foe : "";
$header .= "<div class=\"toplinks\"><a href=\"" . (!$disabled ? "index.php?ACTION=ranking" : "#") . "\">".$fa."Rangliste".$fe."</a></div>";
$header .= "<div class=\"sap\"></div>";
++$c;
$fa = ($current == $c) ? $foa : "";
$fe = ($current == $c) ? $foe : "";
$header .= "<div class=\"toplinks\"><a href=\"index.php?ACTION=howto\">".$fa."How to".$fe."</a></div>";
$header .= "</div>";
$header .= "<div id=\"rc2\"></div></div>";
if (!$disabled) {
	if (upTime()+600 < time()) {
		check_update();
	}
	$query = "SELECT * FROM `spieler` WHERE ID = " . uid();
	$result = mysql_query($query);
	$spieler = mysql_fetch_array($result);
	$balance = $spieler["BALANCE"];
	$totalbalance = $spieler["TOTALBALANCE"];
	
	
	$nu_sec = (upTime()+600) - time();
	$alt_min = floor($nu_sec / 60);
	$alt_sec = $nu_sec - $alt_min * 60;
	
	if ($balance < 0) 
		$balance = "<font color=red>$balance</font>";
	if ($totalbalance < 0)
		$totalbalance = "<font color=red>$totalbalance</font>";
	$header .= "<div><table width=100% style=\"background-image:url({IMAGE_DIR}/heading_bg.gif)\"><tr>
	<th align=left>Kontostand:$balance&euro;</th>
	<th>Gesamtverm&ouml;gen: $totalbalance&euro;</a></th>
	<th>Update in: <span id=\"timed\">$alt_min Minuten $alt_sec Sekunden</span></th>
	<th align=right>Platz: <a href =\"index.php?ACTION=ranking\">".$spieler["RANK"]."</a></th>
	</tr></table>
	</div>
	<script language=\"JavaScript\">
	var sec = $nu_sec;
	function countdown(sec) {
	  var min = parseInt(sec / 60);
	  var sek = sec - (min * 60);
	  document.getElementById(\"timed\").textContent = \"\" + min + \" Minuten \" + sek + \" Sekunden\";
	  if (sec == '0') window.clearInterval(count);
	}
	var count = window.setInterval(\"countdown(--sec)\",1000);

	</script>";
}

return $header;
}

?>