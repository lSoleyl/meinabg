<?php

function __loadcontent() {
   $socket = fsockopen("www.boerse.de", 80, $errno, $errstr);
  if (!$socket)
   die($errno. ":" . $errstr);
  else {
	$out = "POST /ajax/table.php HTTP/1.1\r\n";
    $out .= "Host: www.boerse.de\r\n";
    $out .= "Connection: Close\r\n";
	$out .= "Content-Length: 146\r\n";
	$out .= "Content-Type: application/x-www-form-urlencoded\r\n";
	$out .= "Accept: text/html\r\n\r\n";
	$out .= "K_PAGE_SIZE=500&K_RESEARCH=0&K_RESEARCH_TIME=0d&LISTID=lak_52%4016&";
	$out .= "FIELDS%5B0%5D=N&FIELDS%5B1%5D=b&FIELDS%5B2%5D=a&FIELDS%5B3%5D=p&START=0&END=500\r\n";
	
	fwrite($socket, $out);
	$content = "";
	

	while(!feof($socket)) {
		$r = fgets($socket, 10000);
		preg_match("/^[0-9a-f]{0,5}/", $r, $matches);
		if ($matches[0] != trim($r))
			$content .= $r;
	}
    fclose($socket);
	
	return $content;
  }
}

function __update_shares() {
  $content = __loadcontent();
  $trans = array(
  "\n" => "", 
  "\r" => "", 
  "Ä" => "&Auml;", 
  "ä" => "&auml;", 
  "Ü" => "&Uuml;", 
  "ü" => "&uuml;", 
  "Ö" => "&Ouml;", 
  "ö" => "&ouml;", 
  "ß" => "&szlig;");
  $content = strtr($content, $trans);
  
  $regex = '/.*?id="(?P<id>DE[0-9A-Za-z]*)_N_bg".*?title="(?P<name>[^"]*).*?id=[^>]*>(?P<bid>[^<]*).*?id=[^>]*>(?P<ask>[^<]*).*?id=[^>]*>(?P<p>[^<]*)/';
  preg_match_all($regex, $content, $matches);
  $length = count($matches["id"]);
  
  for ($c = 0; $c < $length; ++$c) {
	$id = $matches["id"][$c];
	$name = $matches["name"][$c];
	$vp = str_replace(",",".",$matches["bid"][$c]);
	$kp = str_replace(",",".",$matches["ask"][$c]);
	$kurs = str_replace(",",".",$matches["p"][$c]);
	
	if (!__check_share($kp, $vp, $kurs, $id)) //check_shares can't fix everything...
		continue;
	
	$query = "SELECT * FROM `aktie` WHERE ID = \"$id\"";
	$result = mysql_query($query);
	if (mysql_errno()) continue;
	else if (mysql_numrows($result) == 1)
		$query = "UPDATE `aktie` SET NAME=\"$name\", VP=$vp, KP=$kp, KURS=$kurs WHERE ID=\"$id\"";
	else 
		$query = "INSERT INTO `aktie` (ID, NAME, VP, KP, KURS) VALUES (\"$id\", \"$name\", $vp, $kp, $kurs)";
	mysql_query($query);
	if (mysql_errno()) {
		if ($res = fopen($RESS_ROOT_DIR . "update-errors.log", 'a')) {
			fwrite($res, date("d.m.y H:i:s", time()) .  " ::__update_shares()::MySQL-Err#". mysql_errno() . ":" . mysql_error(). "    Query=\"$query\"\n");
			fclose($res);
		}
	}
  }
}

function __update_ranks() {
	$query = "SELECT `spieler`.ID AS SID, RANK,(BALANCE+COALESCE(PREIS,0)) AS TOTAL FROM `spieler` LEFT OUTER JOIN (SELECT SPIELERID, SUM(VP*ANZAHL) AS PREIS FROM  `besitzt`,`aktie` WHERE AKTIENID = `aktie`.ID GROUP BY SPIELERID) AS AKT ON `spieler`.ID = `AKT`.SPIELERID ORDER BY TOTAL DESC, RANK ASC";
	$result = mysql_query($query);
	if (mysql_errno()) {
		if ($res = fopen($RESS_ROOT_DIR . "update-errors.log", 'a')) {
			fwrite($res, date("d.m.y H:i:s", time()) .  " ::__update_ranks()::MySQL-Err#". mysql_errno() . ":" . mysql_error(). "    Query=\"$query\"\n");
			fclose($res);
		}
	}
	$length = mysql_numrows($result);
	for($c = 0; $c < $length;) {
		$id = mysql_result($result, $c, "SID");
		$rank = mysql_result($result, $c, "RANK");
		$total = mysql_result($result, $c, "TOTAL");
		$query = "UPDATE `spieler` SET RANK = " . ++$c . ", LASTRANK = $rank, TOTALBALANCE = $total WHERE ID = $id";
		mysql_query($query);	
	}
	
	$query = "UPDATE `ally` SET TOTAL = (SELECT SUM(TOTALBALANCE) FROM `spieler` WHERE ALLY = `ally`.ID), AVG = (SELECT AVG(TOTALBALANCE) FROM `spieler` WHERE ALLY = `ally`.ID)";
	mysql_query($query);
	$query = "SELECT * FROM `ally` ORDER BY AVG DESC, RANK ASC";
	$result = mysql_query($query);
	$c = 0;
	while ($ally = mysql_fetch_array($result)) {
		$query = "UPDATE `ally` SET RANK = " . ++$c . ", OLDRANK = ". $ally["RANK"] . " WHERE ID = " . $ally["ID"];
		mysql_query($query);
	}
}

function __update_trader() {
	

}

function check_update() {
	$result = mysql_query("SELECT LASTUPDATE, TRADE FROM `game` WHERE ENTRYID=1");
	$time = time();
	if (mysql_numrows($result) == 1) { //Don't print an error
		$up = mysql_result($result, 0,"LASTUPDATE");
		$tr = mysql_result($result, 0,"TRADE");
		if ($time - $up > 600) {
			mysql_query("UPDATE `game` SET LASTUPDATE=$time WHERE ENTRYID=1");
			$day = date("D", $time);
			if ($day != "Sat" && $day != "Sun") {
				$time = date("H", $time);
				if ($time >= 9 && $time < 20) {
					__update_shares();
					mysql_query("UPDATE `game` SET TRADE=1 WHERE ENTRYID=1"); //Now update the autotraders
				}
			}
			__update_ranks();
		} else if ($tr == 1) {
			mysql_query("UPDATE `game` SET TRADE=0 WHERE ENTRYID=1"); //Only update once!
			__update_trader();
		}
	}
	$result = mysql_query("SELECT LASTUPDATE FROM `game` WHERE ENTRYID=1");
	setUpTime(mysql_result($result,0,0));
}

/** A very clever value-fixer. Tries to fix the values passed to it.
 * If it fails it returns false.
 */
function __check_share(&$kp, &$vp, &$kurs, $id) {
	$okp = $kp;
	$ovp = $vp;
	$okurs = $kurs;
	
	$fails = 0;
	if (!is_numeric($kp))
		++$fails;
	if (!is_numeric($vp))
		++$fails;
	if (!is_numeric($kurs))
		++$fails;
	
	$rem = array("a","b","c","d","e","f");
	if($fails == 3) { //Impossible
		if ($res = fopen($RESS_ROOT_DIR . "corrupted_shares.log", 'a')) {
			fwrite($res, date("d.m.y H:i:s", time()) .  " ::__check_share()::Aktie '$id' kann nicht verarbeitet werden(3 Fehler) : KP:$kp KURS:$kurs VP:$vp \n");
			fclose($res);
		}
		return false;
	} else if ($fails <= 2) { //Could fail sometimes
		$kp = str_replace($rem, "", $kp);
		$vp = str_replace($rem, "", $vp);
		$kurs = str_replace($rem, "", $kurs);
	}
	//Logic check
	if ($kurs == "")
		$kurs = ($kp + $vp) / 2;
	$d1 = $kp - $kurs;
	$d2 = $kurs - $vp;
	$d3 = $kp - $vp;
	
	if ($d1 < 0 && $d2 >= 0) { //Kurs zu hoch
		$kurs = $vp + floor($d3/2);
		if ($res = fopen($RESS_ROOT_DIR . "corrupted_shares.log", 'a')) {
			fwrite($res, date("d.m.y H:i:s", time()) .  " ::__check_share()::Aktie '$id' korrigiert : <KURS_ALT:$okurs> KP:$kp KURS:$kurs VP:$vp \n");
			fclose($res);	
		}
	} else if ($d1 >= 0 && $d2 < 0) { //VP zu hoch
		$vp = $kurs - $d1;
		if ($res = fopen($RESS_ROOT_DIR . "corrupted_shares.log", 'a')) {
			fwrite($res, date("d.m.y H:i:s", time()) .  " ::__check_share()::Aktie '$id' korrigiert : <VP_ALT:$ovp> KP:$kp KURS:$kurs VP:$vp \n");
			fclose($res);	
		}
	}

	if ($d1 >= 0 && $d2 >= 0) { //Scheint alles in Ordnung... KP könnte aber zu hoch sein
		if ($d1 > ($d3 / 2 + 3)) { //KP definitiv zu hoch
			$kp = $kurs + $d2;
			if ($res = fopen($RESS_ROOT_DIR . "corrupted_shares.log", 'a')) {
				fwrite($res, date("d.m.y H:i:s", time()) .  " ::__check_share()::Aktie '$id' korrigiert : <KP_ALT:$okp> KP:$kp KURS:$kurs VP:$vp \n");
				fclose($res);	
			}
		}
		return true;
	}	
}
?>